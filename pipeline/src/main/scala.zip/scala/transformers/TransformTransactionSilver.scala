package transformers

import config.{ConfigVariables, DatalakeConfig}
import interfaces.Transform
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import services.HudiService
import utils.TransformUtils

class TransformTransactionSilver(hudiService: HudiService) extends Transform {
  private val configVars = new ConfigVariables();

  override def stgSilver(df: DataFrame): DataFrame = {
    val dataSchema: StructType = StructType(Seq(
      StructField("transaction_id", StringType),
      StructField("customer_id", StringType),
      StructField("product_id", StringType),
      StructField("phone_number", StringType),
      StructField("product_name", StringType),
      StructField("price", DecimalType(10, 2)),
      StructField("quantity", LongType),
      StructField("total_amount", DecimalType(10, 2)),
      StructField("event_time", LongType),
      StructField("source", StringType)
    ))
    val cdcSchema = StructType(Seq(
      // StructField("before", dataSchema, true),
      StructField("after", dataSchema, true),
      // StructField("op", StringType, true),     // 'c' cho create, 'u' cho update, 'd' cho delete
      StructField("ts_ms", LongType, true)
    ));

    var rawDf : DataFrame = df.where(col("key") === "transaction").select(col("value"));
    var transaction: DataFrame = rawDf.select(from_json(col("value").cast(StringType), cdcSchema).alias("after_value"));
    transaction = transaction.select(col("after_value.after.*"), (col("after_value.ts_ms") / 1000).cast(TimestampType).alias("timestamp")).withWatermark("timestamp", "10 minutes");
    transaction = transaction.filter(col("phone_number").isNotNull);
    transaction = TransformUtils.normalizePhoneNumber(transaction);

    val finalDf = this.resolve(transaction);
    return finalDf;
  }

  private def resolve(transactionDf : DataFrame): DataFrame = {
    var customerDf = hudiService.readStreamTable(s"s3a://${configVars.BUCKET}/silver/silver_customer" );
    customerDf = customerDf.withColumn("arrival_time", current_timestamp()).withWatermark("arrival_time", "1 hour");

    var joinedDf = transactionDf.as("t").join(
      customerDf.as("c"),
      expr("""t.phone_number = c.phone_number AND t.timestamp >= c.arrival_time - interval 100 days AND t.timestamp <= c.arrival_time + interval 100 days"""),
      joinType = "left",
    )
    val finalDf = joinedDf.select(
      col("t.*"),
      col("c.customer_id").as("existing_customer_id"),
      when(col("c.customer_id").isNull, expr("uuid()"))
        .otherwise(col("c.customer_id")).as("final_customer_id"),
      when(col("c.customer_id").isNull, lit(true))
        .otherwise(lit(false)).as("is_new_customer")
    ).select(
      col("transaction_id"),
      col("final_customer_id").as("customer_id"),
      col("product_id"),
      col("product_name"),
      col("price"),
      col("quantity"),
      col("total_amount"),
      col("event_time"),
      col("source"),
      col("phone_number"), // Cần giữ lại để tạo profile customer mới
      col("is_new_customer")
    )

    return finalDf;
  }

  override def stgGold(df: DataFrame): DataFrame = null
}
